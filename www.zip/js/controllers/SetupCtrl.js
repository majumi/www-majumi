﻿app.controller('SetupCtrl', function($scope, $stateParams) {
    $scope.ativaMenuButton = false;
});